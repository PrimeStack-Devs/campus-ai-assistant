# Kryvix Campus AI Assistant - Template Documentation & Guide

Welcome to the Kryvix Campus AI Assistant Data Management Suite.
This package contains all standardized spreadsheet templates used to train and feed Kryvix's knowledge base and vector memory.

## Included Templates (Both .xlsx and .csv formats):

1. **buildings_template.xlsx / .csv** - Campus blocks, zones, institutes, and GPS coordinates.
2. **facilities_template.xlsx / .csv** - Canteens, washrooms, ATMs, placement cells, and labs.
3. **faculty_template.xlsx / .csv** - Faculty directory, roles, cabin locations, and emails.
4. **departments_template.xlsx / .csv** - Academic departments, HOD details, and degree programs.
5. **paths_template.xlsx / .csv** - Turn-by-turn walking routes, distances in meters, and landmarks.
6. **services_template.xlsx / .csv** - Campus libraries, medical centers, gym, and rules.
7. **bus_schedules_template.xlsx / .csv** - Bus transit routes, morning departures, and stops.
8. **office_hours_template.xlsx / .csv** - Administrative service counters and operating hours.
9. **academic_calendar_template.xlsx / .csv** - Semesters, exam periods, and result dates.
10. **important_dates_template.xlsx / .csv** - Important university events and deadlines.
11. **holidays_template.xlsx / .csv** - Gazetted holidays and vacation periods.
12. **policies_template.xlsx / .csv** - Academic policies, rules, and student regulations.
13. **campus_master_template.xlsx** - All 12 entity sheets combined into a single workbook.

## How to Ingest Data into Kryvix:
1. Open the desired template in Excel, Google Sheets, or any spreadsheet editor.
2. Replace or extend the sample rows with your university's real records.
3. Keep column headers unchanged. Columns marked with '*' are required.
4. Navigate to the Admin Portal -> **Data Ingestion Hub** (`/admin/documents`).
5. Drag and drop your file into the **Bulk Excel Upload** zone.
6. Kryvix will automatically parse, clean, save, and vectorize your records immediately!
